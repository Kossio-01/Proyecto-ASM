# 🪟 Guía de Instalación - Windows

## 📋 **Requisitos Previos**

### 1. **Instalar Node.js**
1. Ve a https://nodejs.org/
2. Descarga la versión **LTS** (recomendada)
3. Ejecuta el instalador y sigue los pasos
4. ✅ **Verificar instalación:**
   ```cmd
   node --version
   npm --version
   ```
   Deberías ver algo como: `v18.x.x` y `9.x.x`

### 2. **Instalar Git (opcional pero recomendado)**
1. Ve a https://git-scm.com/download/win
2. Descarga e instala
3. Durante la instalación, acepta todas las opciones por defecto

---

## 🚀 **Instalación del Proyecto**

### **Opción A: Clonar con Git (Recomendado)**
```cmd
# 1. Abrir Command Prompt o PowerShell
# 2. Navegar a donde quieras el proyecto (ej: Escritorio)
cd Desktop

# 3. Clonar el repositorio
git clone [URL_DEL_REPOSITORIO]
cd Proyecto-ASM/backend

# 4. Instalar dependencias
npm install
```

### **Opción B: Descarga Manual**
1. Descarga el proyecto como ZIP desde GitHub
2. Extrae en tu carpeta deseada
3. Abre **Command Prompt** o **PowerShell**
4. Navega a la carpeta:
   ```cmd
   cd C:\ruta\donde\extraiste\Proyecto-ASM\backend
   ```
5. Instala dependencias:
   ```cmd
   npm install
   ```

---

## 🎯 **Iniciar el Servidor**

### **Comando Principal:**
```cmd
# Desde la carpeta backend/
npm run dev
```

### **¿Qué verás?**
```
🚀 Servidor corriendo en http://localhost:3000
📋 API disponible en http://localhost:3000/actividades
💚 Health check en http://localhost:3000/health
```

### **Si ves errores, usa:**
```cmd
# Verificar que estás en la carpeta correcta
dir
# Deberías ver: server.js, package.json, etc.

# Reinstalar dependencias si es necesario
npm install

# Iniciar en modo normal
npm start
```

---

## 🌐 **Acceder a la Aplicación**

1. **Abre tu navegador favorito** (Chrome, Edge, Firefox)
2. **Ve a:** `http://localhost:3000`
3. **¡Listo!** Verás la interfaz de gestión de actividades

### **URLs importantes:**
- **🏠 Interfaz principal:** http://localhost:3000
- **📡 API directa:** http://localhost:3000/actividades
- **💚 Estado del servidor:** http://localhost:3000/health

---

## 🛠️ **Comandos Útiles**

```cmd
# Iniciar servidor (desarrollo - se reinicia automáticamente)
npm run dev

# Iniciar servidor (producción)
npm start

# Detener servidor
Ctrl + C

# Ver archivos en la carpeta actual
dir

# Cambiar de carpeta
cd nombre_carpeta

# Volver a carpeta anterior
cd..

# Ver versiones instaladas
node --version
npm --version
```

---

## ❌ **Solución de Problemas Comunes**

### **"npm no se reconoce como comando"**
- Node.js no está instalado correctamente
- **Solución:** Reinstala Node.js desde https://nodejs.org/

### **"Cannot find module"**
- Las dependencias no están instaladas
- **Solución:**
  ```cmd
  npm install
  ```

### **"Puerto 3000 en uso"**
- Otro programa está usando el puerto 3000
- **Solución:** Mata el proceso y reinicia:
  ```cmd
  # En Command Prompt como Administrador
  netstat -ano | findstr :3000
  taskkill /PID [NUMERO_DEL_PID] /F
  ```

### **"Error de permisos"**
- **Solución:** Ejecuta Command Prompt como **Administrador**
    - Click derecho en Command Prompt
    - "Ejecutar como administrador"

### **El servidor inicia pero no puedo acceder**
- Verifica que no tengas antivirus/firewall bloqueando
- Prueba con: http://127.0.0.1:3000
- Desactiva temporalmente Windows Firewall

---

## 📱 **Para Móviles (Mismo WiFi)**

Si quieres que tus compañeros accedan desde sus celulares:

1. **Encuentra tu IP local:**
   ```cmd
   ipconfig
   ```
   Busca algo como: `192.168.1.xxx`

2. **Inicia el servidor normalmente**

3. **Desde el celular (conectado al mismo WiFi):**
   `http://192.168.1.xxx:3000`


--- 
## 💡 **Tips para Windows**

✅ **Usa PowerShell** en lugar de CMD para mejor experiencia  
✅ **Pin Node.js** al menú inicio para acceso rápido  
✅ **Crea acceso directo** a la carpeta del proyecto  
✅ **Usa VS Code** como editor si lo tienen instalado

---