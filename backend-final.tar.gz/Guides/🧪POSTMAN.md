# 🧪 Guía de Pruebas con Postman - API Actividades

## 🚀 Configuración Inicial

1. **Inicia  servidor :**
   ```bash
   npm run dev
   ```

2. **URL Base en Postman:** `http://localhost:3000`

---

## 📋 **1. GET - Obtener todas las actividades**

**URL:** `GET http://localhost:3000/actividades`

**Headers:** (Opcional)
```
Content-Type: application/json
```

**Resultado esperado:**
```json
{
  "actividades": [
    {
      "id": 1,
      "descripcion": "Configurar el servidor backend",
      "usuario": "developer1",
      "realizada": true,
      "fechaCreacion": "2024-01-15T08:00:00.000Z",
      "fechaCompletada": "2024-01-15T10:30:00.000Z"
    }
  ],
  "total": 4,
  "pendientes": 2,
  "completadas": 2
}
```

---

## ✅ **2. POST - Crear nueva actividad**

**URL:** `POST http://localhost:3000/actividades`

**Headers:**
```
Content-Type: application/json
```

**Body (raw - JSON):**
```json
{
  "descripcion": "Probar la API con Postman",
  "usuario": "tester_postman"
}
```

**Resultado esperado:**
```json
{
  "mensaje": "Actividad creada exitosamente",
  "actividad": {
    "id": 5,
    "descripcion": "Probar la API con Postman",
    "usuario": "tester_postman",
    "realizada": false,
    "fechaCreacion": "2024-01-15T15:30:00.000Z",
    "fechaCompletada": null
  }
}
```

---

## 🔄 **3. PUT - Actualizar actividad**

**URL:** `PUT http://localhost:3000/actividades/5`

**Headers:**
```
Content-Type: application/json
```

**Body (raw - JSON):**
```json
{
  "realizada": true
}
```

**O para cambiar descripción:**
```json
{
  "descripcion": "Probar la API con Postman - COMPLETADO",
  "realizada": true
}
```

---

## 🗑️ **4. DELETE - Eliminar actividad**

**URL:** `DELETE http://localhost:3000/actividades/5`

**Headers:** (Opcional)
```
Content-Type: application/json
```

---

## 📊 **5. GET - Estadísticas (NUEVA FUNCIONALIDAD)**

**URL:** `GET http://localhost:3000/actividades/estadisticas`

**Resultado esperado:**
```json
{
  "resumen": {
    "total": 4,
    "completadas": 2,
    "pendientes": 2
  },
  "usuarios": [
    {
      "usuario": "developer1",
      "total": 2,
      "completadas": 2,
      "pendientes": 0
    },
    {
      "usuario": "designer1",
      "total": 1,
      "completadas": 0,
      "pendientes": 1
    }
  ],
  "fechaConsulta": "2024-01-15T15:45:00.000Z"
}
```

---

## 🔍 **6. GET - Filtros (NUEVA FUNCIONALIDAD)**

### Filtrar por usuario:
**URL:** `GET http://localhost:3000/actividades?usuario=developer1`

### Filtrar por estado:
**URL:** `GET http://localhost:3000/actividades?realizada=false`

### Combinar filtros:
**URL:** `GET http://localhost:3000/actividades?usuario=developer1&realizada=true`

---

## 💚 **7. Health Check**

**URL:** `GET http://localhost:3000/health`

**Resultado:**
```json
{
  "status": "OK",
  "timestamp": "2024-01-15T15:50:00.000Z",
  "uptime": 120.5
}
```

---

## 🧪 **Casos de Prueba de Validaciones**

### **Validación 1: Descripción vacía**
**POST** `http://localhost:3000/actividades`
```json
{
  "descripcion": "",
  "usuario": "test"
}
```
**Esperado:** Error 400

### **Validación 2: Descripción muy larga**
**POST** `http://localhost:3000/actividades`
```json
{
  "descripcion": "Esta es una descripción extremadamente larga que excede los 500 caracteres permitidos por el sistema de validación... [continuar hasta superar 500 caracteres]",
  "usuario": "test"
}
```
**Esperado:** Error 400

### **Validación 3: Sin usuario (debería usar default)**
**POST** `http://localhost:3000/actividades`
```json
{
  "descripcion": "Actividad sin usuario específico"
}
```
**Esperado:** Usuario = "usuario_anonimo"

---

## 📚 **Colección de Postman**

Para hacer las pruebas más fáciles, puedes crear una colección con estos requests:

1. **Abre Postman**
2. **New Collection** → "Actividades API"
3. **Agrega cada request** con los datos de arriba
4. **Guarda variables de entorno:**
    - `base_url` = `http://localhost:3000`
    - `test_id` = `1` (para las pruebas de actualización)

---

## 🔥 **Diferencias con la versión anterior:**

✅ **Mejores respuestas:** Ahora incluye más información  
✅ **Validaciones:** Errores más claros  
✅ **Nuevos endpoints:** Estadísticas y health check  
✅ **Filtros:** Búsquedas más específicas  
✅ **Timestamps:** Fechas de creación y completado  
✅ **Usuarios:** Soporte multiusuario
