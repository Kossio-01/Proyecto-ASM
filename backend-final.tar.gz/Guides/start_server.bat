@echo off
title Actividades API - Servidor Backend
color 0A

echo.
echo  ====================================================
echo   📋 ACTIVIDADES API - SERVIDOR BACKEND
echo   ====================================================
echo.

REM Ir a la carpeta backend (un nivel arriba desde guides)
cd ..

REM Verificar si Node.js está instalado
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  ❌ ERROR: Node.js no está instalado
    echo  📥 Descargalo desde: https://nodejs.org/
    pause
    exit /b 1
)

echo  ✅ Node.js detectado:
node --version

REM Verificar si estamos en la carpeta correcta
if not exist "package.json" (
    echo.
    echo  ❌ ERROR: No se encontró package.json
    echo  📁 Ubicación actual:
    cd
    echo.
    pause
    exit /b 1
)

echo  ✅ Proyecto encontrado
echo.

REM Verificar dependencias
if not exist "node_modules" (
    echo  📦 Instalando dependencias por primera vez...
    echo.
    npm install
    if %errorlevel% neq 0 (
        echo.
        echo  ❌ ERROR: Falló la instalación de dependencias
        pause
        exit /b 1
    )
) else (
    echo  ✅ Dependencias ya instaladas
)

echo.
echo  🚀 Iniciando servidor...
echo.
echo  ====================================================
echo   URLs DISPONIBLES:
echo   🏠 Interfaz web:  http://localhost:3000
echo   📡 API:          http://localhost:3000/actividades
echo   💚 Health:       http://localhost:3000/health
echo  ====================================================
echo.
echo  💡 Presiona Ctrl+C para detener el servidor
echo.

REM Abrir navegador automáticamente (opcional)
timeout /t 3 >nul
start http://localhost:3000

REM Iniciar servidor
npm run dev

echo.
echo  👋 Servidor detenido. Presiona cualquier tecla para salir.
pause >nul