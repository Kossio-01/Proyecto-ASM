# 📋 API de Gestión de Actividades

API REST moderna para gestión de actividades/tareas con soporte multiusuario, construida con Node.js y Express.

## 🚀 Instalación y Uso

```bash
# Clonar el repositorio
git clone <url-del-repo>
cd actividades-api

# Instalar dependencias
npm install

# Modo desarrollo (con auto-reload)
npm run dev

# Modo producción
npm start
```

La API estará disponible en: `http://localhost:3000`

## 📡 Endpoints Disponibles

### **GET /actividades**
Obtiene todas las actividades con filtros opcionales.

**Query Parameters:**
- `usuario` (string, opcional): Filtrar por usuario
- `realizada` (boolean, opcional): Filtrar por estado (`true`/`false`)

**Respuesta:**
```json
{
  "actividades": ["..."],
  "total": 5,
  "pendientes": 2,
  "completadas": 3
}
```

### **POST /actividades**
Crea una nueva actividad.

**Body:**
```json
{
  "descripcion": "Completar el proyecto",
  "usuario": "juan.perez"
}
```

**Validaciones:**
- `descripcion`: Requerida, máximo 500 caracteres
- `usuario`: Opcional, máximo 50 caracteres (default: "usuario_anonimo")

### **PUT /actividades/:id**
Actualiza una actividad existente.

**Body:**
```json
{
  "descripcion": "Nueva descripción",
  "realizada": true
}
```

### **DELETE /actividades/:id**
Elimina una actividad.

### **GET /actividades/estadisticas**
Obtiene estadísticas generales y por usuario.

**Respuesta:**
```json
{
  "resumen": {
    "total": 10,
    "completadas": 6,
    "pendientes": 4
  },
  "usuarios": ["..."],
  "fechaConsulta": "2024-01-15T10:30:00.000Z"
}
```

### **GET /health**
Endpoint para monitoreo del estado del servidor.

## 🔧 Estructura del Proyecto

```
actividades-api/
├── server.js                 # Servidor principal
├── controllers/
│   └── actividadesController.js  # Lógica de negocio
├── routes/
│   └── actividades.js        # Definición de rutas
├── data/
│   └── actividades.json      # Almacenamiento de datos
├── public/                   # Archivos estáticos (opcional)
├── package.json
└── README.md
```

## 🌟 Características Avanzadas

✅ **Validaciones robustas**: Límites de caracteres y tipos de datos  
✅ **Soporte multiusuario**: Campo usuario en cada actividad  
✅ **Filtros de búsqueda**: Por usuario y estado  
✅ **Estadísticas completas**: Resumen general y por usuario  
✅ **Manejo de errores**: Respuestas HTTP apropiadas  
✅ **CORS habilitado**: Listo para frontend  
✅ **Logging básico**: Registro de operaciones  
✅ **Timestamps**: Fecha de creación y completado

## 🚀 Deploy a Producción

### Railway (Recomendado - Gratis)
1. Conecta tu repositorio GitHub con Railway
2. Railway detectará automáticamente Node.js
3. Tu API estará disponible en: `https://tu-app.up.railway.app`

### Render (Alternativa gratuita)
1. Conecta tu repo en render.com
2. Configura el build command: `npm install`
3. Start command: `npm start`

## 📝 Ejemplos de Uso

### Crear actividad:
```bash
curl -X POST http://localhost:3000/actividades \
  -H "Content-Type: application/json" \
  -d '{"descripcion": "Revisar código", "usuario": "developer1"}'
```

### Obtener actividades pendientes:
```bash
curl "http://localhost:3000/actividades?realizada=false"
```

### Marcar como completada:
```bash
curl -X PUT http://localhost:3000/actividades/1 \
  -H "Content-Type: application/json" \
  -d '{"realizada": true}'
```

## 🤝 Para el Equipo Frontend

Esta API está lista para integrarse con cualquier frontend :

- ✅ CORS configurado
- ✅ Respuestas JSON consistentes
- ✅ Códigos HTTP apropiados
- ✅ Documentación completa
- ✅ Deploy en la nube disponible

**URL de desarrollo:** `http://localhost:3000`
---

💡 **Próximas mejoras:** Autenticación JWT, paginación, búsqueda por texto, notificaciones en tiempo real.