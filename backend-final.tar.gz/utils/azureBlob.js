const { BlobServiceClient } = require('@azure/storage-blob');

const sasUrl = process.env.AZURE_BLOB_SAS_URL; // e.g. https://<account>.blob.core.windows.net/<container>?<SAS>
const containerName = process.env.AZURE_BLOB_CONTAINER; // e.g. 'images'

async function uploadImageToAzure(fileBuffer, fileName, mimeType) {
    const blobServiceClient = new BlobServiceClient(sasUrl);
    const containerClient = blobServiceClient.getContainerClient(containerName);
    const blockBlobClient = containerClient.getBlockBlobClient(fileName);

    await blockBlobClient.uploadData(fileBuffer, {
        blobHTTPHeaders: { blobContentType: mimeType }
    });

    return blockBlobClient.url;
}

module.exports = { uploadImageToAzure };