// backend/server.js - VERSIÓN LIMPIA
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

// Configuración para diferentes entornos
const isProduction = process.env.NODE_ENV === 'production';

// Middlewares
app.use(cors({
    origin: isProduction ?
        ['https://asmpance-api.azurewebsites.net'] :
        ['http://localhost:3000', 'http://localhost:3001']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging middleware para Azure
if (isProduction) {
    app.use((req, res, next) => {
        console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
        next();
    });
}

// Importar rutas con manejo de errores
let authRoutes, markerRoutes;

try {
    authRoutes = require('./routes/auth');
    markerRoutes = require('./routes/markers');
} catch (error) {
    console.error('❌ Error cargando rutas:', error.message);
    process.exit(1);
}

// API routes first
app.use('/api/auth', authRoutes);
app.use('/api/markers', markerRoutes);

// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        environment: process.env.NODE_ENV || 'development',
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
    });
});

// Servir archivos estáticos desde public/ DESPUÉS de las rutas API
app.use(express.static(path.join(__dirname, 'public')));

// Catch all handler - servir index.html para cualquier ruta que no sea API
app.get('*', (req, res) => {
    const indexPath = path.join(__dirname, 'public', 'index.html');
    res.sendFile(indexPath, (err) => {
        if (err) {
            res.status(404).send('<h1>404 - Página no encontrada</h1>');
        }
    });
});

// Manejo global de errores
app.use((error, req, res, next) => {
    console.error('❌ Error global:', error.stack);
    res.status(500).json({
        error: isProduction ? 'Error interno del servidor' : error.message,
        timestamp: new Date().toISOString()
    });
});

const PORT = process.env.PORT || 3001;

const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Servidor corriendo en puerto ${PORT}`);
    console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}`);
    console.log(`📁 Sirviendo archivos desde: ${path.join(__dirname, 'public')}`);
});

process.on('SIGTERM', () => {
    console.log('📴 Cerrando servidor...');
    server.close(() => {
        console.log('✅ Servidor cerrado correctamente');
        process.exit(0);
    });
});

module.exports = app;