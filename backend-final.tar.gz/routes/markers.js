// backend/routes/markers.js
const express = require('express');
const router = express.Router();

// Array en memoria para almacenar marcadores (temporal)
// En producción deberías usar una base de datos
let markers = [];
let nextId = 1;

// GET /api/markers - Obtener todos los marcadores
router.get('/', (req, res) => {
    console.log(`📋 Obteniendo ${markers.length} marcadores`);
    res.json(markers);
});

// POST /api/markers - Crear nuevo marcador
router.post('/', (req, res) => {
    const { name, description, lat, lng } = req.body;

    // Validar datos requeridos
    if (!name || !lat || !lng) {
        return res.status(400).json({
            error: 'Faltan campos requeridos: name, lat, lng'
        });
    }

    // Crear nuevo marcador
    const newMarker = {
        id: nextId++,
        name: name.trim(),
        description: description ? description.trim() : '',
        lat: parseFloat(lat),
        lng: parseFloat(lng),
        createdAt: new Date().toISOString()
    };

    // Verificar si ya existe un marcador muy cerca (para evitar duplicados)
    const existingMarker = markers.find(marker =>
        Math.abs(marker.lat - newMarker.lat) < 0.0001 &&
        Math.abs(marker.lng - newMarker.lng) < 0.0001
    );

    if (existingMarker) {
        // Actualizar marcador existente en lugar de crear duplicado
        existingMarker.name = newMarker.name;
        existingMarker.description = newMarker.description;
        console.log(`🔄 Marcador actualizado: ${existingMarker.name}`);
        return res.json(existingMarker);
    }

    // Agregar a la lista
    markers.push(newMarker);

    console.log(`➕ Nuevo marcador creado: ${newMarker.name} en ${lat}, ${lng}`);
    res.status(201).json(newMarker);
});

// PUT /api/markers/:id - Actualizar marcador existente
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { name, description, lat, lng } = req.body;

    const markerIndex = markers.findIndex(m => m.id == id);

    if (markerIndex === -1) {
        return res.status(404).json({ error: 'Marcador no encontrado' });
    }

    // Actualizar campos
    if (name) markers[markerIndex].name = name.trim();
    if (description !== undefined) markers[markerIndex].description = description.trim();
    if (lat) markers[markerIndex].lat = parseFloat(lat);
    if (lng) markers[markerIndex].lng = parseFloat(lng);

    markers[markerIndex].updatedAt = new Date().toISOString();

    console.log(`✏️ Marcador ${id} actualizado: ${markers[markerIndex].name}`);
    res.json(markers[markerIndex]);
});

// DELETE /api/markers/:id - Eliminar marcador
router.delete('/:id', (req, res) => {
    const { id } = req.params;
    const markerIndex = markers.findIndex(m => m.id == id);

    if (markerIndex === -1) {
        return res.status(404).json({ error: 'Marcador no encontrado' });
    }

    const deletedMarker = markers.splice(markerIndex, 1)[0];
    console.log(`🗑️ Marcador ${id} eliminado: ${deletedMarker.name}`);

    res.json({ message: 'Marcador eliminado', marker: deletedMarker });
});

// DELETE /api/markers - Eliminar todos los marcadores
router.delete('/', (req, res) => {
    const count = markers.length;
    markers = [];
    nextId = 1;

    console.log(`🧹 ${count} marcadores eliminados`);
    res.json({ message: `${count} marcadores eliminados` });
});

module.exports = router;