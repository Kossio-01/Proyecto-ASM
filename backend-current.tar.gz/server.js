// backend/server.js - Mejorado para Azure
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

// Configuración para diferentes entornos
const isProduction = process.env.NODE_ENV === 'production';

// Middlewares
app.use(cors({
    origin: isProduction ?
        ['https://tu-app.azurewebsites.net'] :
        ['http://localhost:3000', 'http://localhost:3001']
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging middleware para Azure
if (isProduction) {
    app.use((req, res, next) => {
        console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
        next();
    });
}

// Servir archivos estáticos (dashboard)
app.use(express.static(path.join(__dirname, 'public')));

// Importar rutas con manejo de errores
let authRoutes, markerRoutes;

try {
    authRoutes = require('./routes/auth');
    markerRoutes = require('./routes/markers');
} catch (error) {
    console.error('❌ Error cargando rutas:', error.message);
    process.exit(1);
}

// Registrar rutas API
app.use('/api/auth', authRoutes);
app.use('/api/markers', markerRoutes);

// Ruta principal - servir dashboard
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Health check mejorado para Azure
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        environment: process.env.NODE_ENV || 'development',
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        timestamp: new Date().toISOString(),
        version: process.env.npm_package_version || '1.0.0'
    });
});

// Manejo de errores 404
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Ruta no encontrada',
        path: req.originalUrl
    });
});

// Manejo global de errores
app.use((error, req, res, next) => {
    console.error('❌ Error global:', error.stack);
    res.status(500).json({
        error: isProduction ? 'Error interno del servidor' : error.message,
        timestamp: new Date().toISOString()
    });
});

// Configuración del puerto para Azure
const PORT = process.env.PORT || 3001;

const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Servidor corriendo en puerto ${PORT}`);
    console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}`);
});

// Manejo graceful de shutdown
process.on('SIGTERM', () => {
    console.log('📴 Cerrando servidor...');
    server.close(() => {
        console.log('✅ Servidor cerrado correctamente');
        process.exit(0);
    });
});

module.exports = app;